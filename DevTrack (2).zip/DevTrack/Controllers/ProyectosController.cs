using DevTrack.Data;
using DevTrack.Models;
using Microsoft.AspNetCore.Mvc;

namespace DevTrack.Controllers
{
    public class ProyectosController : Controller
    {
        private readonly RepositorioDevTrack _repo;

        public ProyectosController(RepositorioDevTrack repo)
        {
            _repo = repo;
        }

        // GET /Proyectos
        public IActionResult Index()
        {
            Proyecto[] proyectos = _repo.ObtenerProyectos();
            Tarea[] tareas = _repo.ObtenerTareas();
            ProyectoResumenVM[] resumenes = new ProyectoResumenVM[proyectos.Length];

            for (int i = 0; i < proyectos.Length; i++)
            {
                int total = 0, aprobadas = 0;
                foreach (Tarea t in tareas)
                {
                    if (t.ProyectoId != proyectos[i].Id) continue;
                    total++;
                    if (t.Estado == EstadoTarea.Aprobada) aprobadas++;
                }

                resumenes[i] = new ProyectoResumenVM
                {
                    Proyecto = proyectos[i],
                    TotalTareas = total,
                    TareasAprobadas = aprobadas
                };
            }

            return View(resumenes);
        }

        // GET /Proyectos/Detalle/3
        public IActionResult Detalle(int id)
        {
            Proyecto proyecto = _repo.BuscarProyecto(id);
            if (proyecto == null) return NotFound();

            DetalleProyectoVM vm = new DetalleProyectoVM
            {
                Proyecto = proyecto,
                Tareas = _repo.TareasDeProyecto(id)
            };
            return View(vm);
        }

        [HttpGet]
        public IActionResult Crear()
        {
            return View(new Proyecto());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Crear(Proyecto proyecto)
        {
            if (!ModelState.IsValid) return View(proyecto);

            _repo.AgregarProyecto(proyecto);
            TempData["Mensaje"] = $"Proyecto \"{proyecto.Nombre}\" registrado.";
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Editar(int id)
        {
            Proyecto proyecto = _repo.BuscarProyecto(id);
            if (proyecto == null) return NotFound();
            return View(proyecto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(Proyecto proyecto)
        {
            if (!ModelState.IsValid) return View(proyecto);

            if (!_repo.ActualizarProyecto(proyecto)) return NotFound();

            TempData["Mensaje"] = "Proyecto actualizado.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Eliminar(int id)
        {
            if (_repo.EliminarProyecto(id))
                TempData["Mensaje"] = "Proyecto eliminado junto con sus tareas.";

            return RedirectToAction(nameof(Index));
        }
    }
}
