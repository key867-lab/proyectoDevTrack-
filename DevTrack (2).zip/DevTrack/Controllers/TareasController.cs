using DevTrack.Data;
using DevTrack.Models;
using Microsoft.AspNetCore.Mvc;

namespace DevTrack.Controllers
{
    public class TareasController : Controller
    {
        private readonly RepositorioDevTrack _repo;

        public TareasController(RepositorioDevTrack repo)
        {
            _repo = repo;
        }

        // GET /Tareas/Crear?proyectoId=3
        [HttpGet]
        public IActionResult Crear(int proyectoId)
        {
            Proyecto proyecto = _repo.BuscarProyecto(proyectoId);
            if (proyecto == null) return NotFound();

            ViewBag.NombreProyecto = proyecto.Nombre;
            return View(new Tarea { ProyectoId = proyectoId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Crear(Tarea tarea)
        {
            Proyecto proyecto = _repo.BuscarProyecto(tarea.ProyectoId);
            if (proyecto == null) return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.NombreProyecto = proyecto.Nombre;
                return View(tarea);
            }

            _repo.AgregarTarea(tarea);
            TempData["Mensaje"] = $"Tarea \"{tarea.Titulo}\" registrada.";
            return RedirectToAction("Detalle", "Proyectos", new { id = tarea.ProyectoId });
        }

        [HttpGet]
        public IActionResult Editar(int id)
        {
            Tarea tarea = _repo.BuscarTarea(id);
            if (tarea == null) return NotFound();

            ViewBag.NombreProyecto = _repo.BuscarProyecto(tarea.ProyectoId)?.Nombre;
            return View(tarea);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(Tarea tarea)
        {
            Tarea original = _repo.BuscarTarea(tarea.Id);
            if (original == null) return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.NombreProyecto = _repo.BuscarProyecto(original.ProyectoId)?.Nombre;
                return View(tarea);
            }

            _repo.ActualizarTarea(tarea);
            TempData["Mensaje"] = "Tarea actualizada.";
            return RedirectToAction("Detalle", "Proyectos", new { id = original.ProyectoId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Eliminar(int id)
        {
            Tarea tarea = _repo.BuscarTarea(id);
            if (tarea == null) return NotFound();

            int proyectoId = tarea.ProyectoId;
            _repo.EliminarTarea(id);
            TempData["Mensaje"] = "Tarea eliminada.";
            return RedirectToAction("Detalle", "Proyectos", new { id = proyectoId });
        }
    }
}
