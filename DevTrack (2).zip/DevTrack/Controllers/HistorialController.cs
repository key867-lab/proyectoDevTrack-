using DevTrack.Data;
using DevTrack.Models;
using Microsoft.AspNetCore.Mvc;

namespace DevTrack.Controllers
{
    public class HistorialController : Controller
    {
        private readonly RepositorioSeguimiento _seguimiento;

        public HistorialController(RepositorioSeguimiento seguimiento)
        {
            _seguimiento = seguimiento;
        }

        // GET /Historial
        public IActionResult Index()
        {
            HistorialVM vm = new HistorialVM
            {
                Pila = _seguimiento.ObtenerPilaDeshacer(),
                Historial = _seguimiento.ObtenerHistorial()
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Deshacer()
        {
            Resultado resultado = _seguimiento.Deshacer();
            TempData[resultado.Exito ? "Mensaje" : "Error"] = resultado.Mensaje;
            return RedirectToAction(nameof(Index));
        }
    }
}
