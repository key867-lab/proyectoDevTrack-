using DevTrack.Data;
using DevTrack.Estructuras;
using DevTrack.Models;
using Microsoft.AspNetCore.Mvc;

namespace DevTrack.Controllers
{
    public class SeguimientoController : Controller
    {
        private readonly RepositorioDevTrack _repo;
        private readonly RepositorioSeguimiento _seguimiento;

        public SeguimientoController(RepositorioDevTrack repo, RepositorioSeguimiento seguimiento)
        {
            _repo = repo;
            _seguimiento = seguimiento;
        }

        // GET /Seguimiento
        public IActionResult Index()
        {
            Proyecto[] proyectos = _repo.ObtenerProyectos();
            AvanceProyectoVM[] avances = new AvanceProyectoVM[proyectos.Length];

            for (int i = 0; i < proyectos.Length; i++)
                avances[i] = ConstruirAvance(proyectos[i]);

            return View(avances);
        }

        // GET /Seguimiento/Detalle/3
        public IActionResult Detalle(int id)
        {
            Proyecto proyecto = _repo.BuscarProyecto(id);
            if (proyecto == null) return NotFound();

            return View(ConstruirAvance(proyecto));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Iniciar(int tareaId, int proyectoId)
        {
            Avisar(_seguimiento.IniciarTarea(tareaId));
            return RedirectToAction(nameof(Detalle), new { id = proyectoId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EnviarARevision(int tareaId, int proyectoId)
        {
            Avisar(_seguimiento.EnviarARevision(tareaId));
            return RedirectToAction(nameof(Detalle), new { id = proyectoId });
        }

        /// <summary>Cuenta las tareas por estado y las separa en pendientes y completadas.</summary>
        private AvanceProyectoVM ConstruirAvance(Proyecto proyecto)
        {
            Tarea[] tareas = _repo.TareasDeProyecto(proyecto.Id);
            ListaDinamica<Tarea> pendientes = new ListaDinamica<Tarea>();
            ListaDinamica<Tarea> completadas = new ListaDinamica<Tarea>();
            int[] porEstado = new int[6];   // posiciones 1 a 5, una por estado

            foreach (Tarea t in tareas)
            {
                porEstado[(int)t.Estado]++;

                if (t.Estado == EstadoTarea.Aprobada)
                    completadas.Agregar(t);
                else
                    pendientes.Agregar(t);
            }

            // Las pendientes se ordenan por fecha de entrega (la más cercana primero).
            Tarea[] pendientesOrdenadas = pendientes.ComoArreglo();
            Array.Sort(pendientesOrdenadas, (a, b) => a.FechaEntrega.CompareTo(b.FechaEntrega));

            return new AvanceProyectoVM
            {
                Proyecto = proyecto,
                Total = tareas.Length,
                PorEstado = porEstado,
                Pendientes = pendientesOrdenadas,
                Completadas = completadas.ComoArreglo(),
                Porcentaje = Visual.Porcentaje(completadas.Cantidad, tareas.Length),
                Observaciones = _seguimiento.ObtenerObservaciones()
            };
        }

        private void Avisar(Resultado resultado)
        {
            TempData[resultado.Exito ? "Mensaje" : "Error"] = resultado.Mensaje;
        }
    }
}
