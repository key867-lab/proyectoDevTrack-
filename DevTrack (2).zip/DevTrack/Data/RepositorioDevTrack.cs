using System.Text.Json;
using DevTrack.Estructuras;
using DevTrack.Models;

namespace DevTrack.Data
{
    /// <summary>
    /// Guarda proyectos y tareas en dos ListaDinamica (arreglos redimensionables)
    /// y los persiste en App_Data/devtrack.json cada vez que hay un cambio.
    /// </summary>
    public class RepositorioDevTrack
    {
        private readonly string _ruta;
        private readonly object _candado = new object();

        private readonly ListaDinamica<Proyecto> _proyectos = new ListaDinamica<Proyecto>();
        private readonly ListaDinamica<Tarea> _tareas = new ListaDinamica<Tarea>();
        private int _siguienteIdProyecto = 1;
        private int _siguienteIdTarea = 1;

        private class DatosArchivo
        {
            public int SiguienteIdProyecto { get; set; } = 1;
            public int SiguienteIdTarea { get; set; } = 1;
            public Proyecto[] Proyectos { get; set; } = Array.Empty<Proyecto>();
            public Tarea[] Tareas { get; set; } = Array.Empty<Tarea>();
        }

        public RepositorioDevTrack(IWebHostEnvironment entorno)
        {
            string carpeta = Path.Combine(entorno.ContentRootPath, "App_Data");
            Directory.CreateDirectory(carpeta);
            _ruta = Path.Combine(carpeta, "devtrack.json");
            Cargar();
        }

        // ---------------- PROYECTOS ----------------

        public Proyecto[] ObtenerProyectos()
        {
            lock (_candado) return _proyectos.ComoArreglo();
        }

        public Proyecto BuscarProyecto(int id)
        {
            lock (_candado) return _proyectos.Buscar(p => p.Id == id);
        }

        public void AgregarProyecto(Proyecto proyecto)
        {
            lock (_candado)
            {
                proyecto.Id = _siguienteIdProyecto++;
                _proyectos.Agregar(proyecto);
                Guardar();
            }
        }

        public bool ActualizarProyecto(Proyecto datos)
        {
            lock (_candado)
            {
                int indice = _proyectos.IndiceDe(p => p.Id == datos.Id);
                if (indice < 0) return false;

                _proyectos[indice] = datos;
                Guardar();
                return true;
            }
        }

        /// <summary>Elimina el proyecto y todas sus tareas.</summary>
        public bool EliminarProyecto(int id)
        {
            lock (_candado)
            {
                int indice = _proyectos.IndiceDe(p => p.Id == id);
                if (indice < 0) return false;

                _proyectos.EliminarEn(indice);
                _tareas.EliminarDonde(t => t.ProyectoId == id);
                Guardar();
                return true;
            }
        }

        // ---------------- TAREAS ----------------

        public Tarea[] ObtenerTareas()
        {
            lock (_candado) return _tareas.ComoArreglo();
        }

        public Tarea[] TareasDeProyecto(int proyectoId)
        {
            lock (_candado)
            {
                ListaDinamica<Tarea> resultado = new ListaDinamica<Tarea>();
                foreach (Tarea t in _tareas)
                {
                    if (t.ProyectoId == proyectoId)
                        resultado.Agregar(t);
                }
                return resultado.ComoArreglo();
            }
        }

        public Tarea BuscarTarea(int id)
        {
            lock (_candado) return _tareas.Buscar(t => t.Id == id);
        }

        public bool AgregarTarea(Tarea tarea)
        {
            lock (_candado)
            {
                if (_proyectos.IndiceDe(p => p.Id == tarea.ProyectoId) < 0)
                    return false;

                tarea.Id = _siguienteIdTarea++;
                tarea.Estado = EstadoTarea.Pendiente;
                _tareas.Agregar(tarea);
                Guardar();
                return true;
            }
        }

        public bool ActualizarTarea(Tarea datos)
        {
            lock (_candado)
            {
                int indice = _tareas.IndiceDe(t => t.Id == datos.Id);
                if (indice < 0) return false;

                // Se conservan el proyecto y el estado originales (el estado lo cambia QA).
                Tarea original = _tareas[indice];
                datos.ProyectoId = original.ProyectoId;
                datos.Estado = original.Estado;

                _tareas[indice] = datos;
                Guardar();
                return true;
            }
        }

        public bool EliminarTarea(int id)
        {
            lock (_candado)
            {
                int indice = _tareas.IndiceDe(t => t.Id == id);
                if (indice < 0) return false;

                _tareas.EliminarEn(indice);
                Guardar();
                return true;
            }
        }

        /// <summary>
        /// Cambia solo el estado de una tarea. Lo usa el módulo de seguimiento (Programador 2);
        /// las reglas de qué cambios se permiten están en FlujoEstados.
        /// </summary>
        public bool CambiarEstadoTarea(int id, EstadoTarea nuevoEstado)
        {
            lock (_candado)
            {
                Tarea tarea = _tareas.Buscar(t => t.Id == id);
                if (tarea == null) return false;

                tarea.Estado = nuevoEstado;
                Guardar();
                return true;
            }
        }

        // ---------------- PERSISTENCIA ----------------

        private void Guardar()
        {
            DatosArchivo datos = new DatosArchivo
            {
                SiguienteIdProyecto = _siguienteIdProyecto,
                SiguienteIdTarea = _siguienteIdTarea,
                Proyectos = _proyectos.ComoArreglo(),
                Tareas = _tareas.ComoArreglo()
            };

            string json = JsonSerializer.Serialize(datos, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_ruta, json);
        }

        private void Cargar()
        {
            if (!File.Exists(_ruta)) return;

            try
            {
                string json = File.ReadAllText(_ruta);
                DatosArchivo datos = JsonSerializer.Deserialize<DatosArchivo>(json);
                if (datos == null) return;

                _siguienteIdProyecto = datos.SiguienteIdProyecto;
                _siguienteIdTarea = datos.SiguienteIdTarea;

                foreach (Proyecto p in datos.Proyectos) _proyectos.Agregar(p);
                foreach (Tarea t in datos.Tareas) _tareas.Agregar(t);
            }
            catch (JsonException)
            {
                // Archivo dañado: se inicia vacío en lugar de tumbar la aplicación.
                _proyectos.Limpiar();
                _tareas.Limpiar();
            }
        }
    }
}
