namespace DevTrack.Models
{
    /// <summary>Colores de las etiquetas de estado (los mismos del tablero de proyectos).</summary>
    public static class VisualSeguimiento
    {
        public static string ColorEstado(EstadoTarea estado)
        {
            switch (estado)
            {
                case EstadoTarea.Pendiente: return "ambar";
                case EstadoTarea.EnDesarrollo: return "cobalto";
                case EstadoTarea.EnRevisionQA: return "violeta";
                case EstadoTarea.Aprobada: return "menta";
                case EstadoTarea.Rechazada: return "coral";
                default: return "cobalto";
            }
        }
    }

    public class AvanceProyectoVM
    {
        public Proyecto Proyecto { get; set; }
        public int Total { get; set; }
        public int[] PorEstado { get; set; }          // se consulta con (int)EstadoTarea
        public Tarea[] Pendientes { get; set; }       // todo lo que aún no está aprobado
        public Tarea[] Completadas { get; set; }      // tareas aprobadas
        public int Porcentaje { get; set; }
        public Observacion[] Observaciones { get; set; }
    }

    public class ItemColaVM
    {
        public int Posicion { get; set; }
        public Tarea Tarea { get; set; }
        public string NombreProyecto { get; set; }
        public DateTime FechaEnvio { get; set; }
    }

    public class RevisionVM
    {
        public ItemColaVM[] Cola { get; set; }
        public Observacion[] Observaciones { get; set; }
    }

    public class HistorialVM
    {
        public CambioEstado[] Pila { get; set; }
        public RegistroHistorial[] Historial { get; set; }
    }
}
