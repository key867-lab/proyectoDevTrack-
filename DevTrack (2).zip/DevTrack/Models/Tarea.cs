using System.ComponentModel.DataAnnotations;

namespace DevTrack.Models
{
    public class Tarea
    {
        public int Id { get; set; }

        public int ProyectoId { get; set; }

        [Required(ErrorMessage = "El título es obligatorio.")]
        [StringLength(120, ErrorMessage = "Máximo 120 caracteres.")]
        [Display(Name = "Título")]
        public string Titulo { get; set; }

        [StringLength(500, ErrorMessage = "Máximo 500 caracteres.")]
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; }

        [Required(ErrorMessage = "Asigne un responsable.")]
        [StringLength(80)]
        public string Responsable { get; set; }

        public Prioridad Prioridad { get; set; } = Prioridad.Media;

        [Required(ErrorMessage = "La fecha de entrega es obligatoria.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de entrega")]
        public DateTime FechaEntrega { get; set; } = DateTime.Today.AddDays(7);

        // El cambio de estado lo manejan los módulos de QA/seguimiento de tus compañeros.
        // Aquí toda tarea nueva nace como Pendiente.
        public EstadoTarea Estado { get; set; } = EstadoTarea.Pendiente;
    }
}
