using System.ComponentModel.DataAnnotations;

namespace DevTrack.Models
{
    public class Proyecto : IValidatableObject
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio.")]
        [StringLength(100, ErrorMessage = "Máximo 100 caracteres.")]
        public string Nombre { get; set; }

        [StringLength(500, ErrorMessage = "Máximo 500 caracteres.")]
        public string Descripcion { get; set; }

        [Required(ErrorMessage = "Indique el líder del proyecto.")]
        [StringLength(80)]
        [Display(Name = "Líder del proyecto")]
        public string Lider { get; set; }

        [Required(ErrorMessage = "La fecha de inicio es obligatoria.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de inicio")]
        public DateTime FechaInicio { get; set; } = DateTime.Today;

        [Required(ErrorMessage = "La fecha de entrega es obligatoria.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de entrega")]
        public DateTime FechaEntrega { get; set; } = DateTime.Today.AddDays(30);

        public IEnumerable<ValidationResult> Validate(ValidationContext contexto)
        {
            if (FechaEntrega < FechaInicio)
            {
                yield return new ValidationResult(
                    "La fecha de entrega no puede ser anterior a la de inicio.",
                    new[] { nameof(FechaEntrega) });
            }
        }
    }
}
