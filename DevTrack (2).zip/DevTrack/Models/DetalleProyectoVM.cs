namespace DevTrack.Models
{
    public class DetalleProyectoVM
    {
        public Proyecto Proyecto { get; set; }
        public Tarea[] Tareas { get; set; }
    }

    public class ProyectoResumenVM
    {
        public Proyecto Proyecto { get; set; }
        public int TotalTareas { get; set; }
        public int TareasAprobadas { get; set; }
    }

    public class TareaProxima
    {
        public Tarea Tarea { get; set; }
        public string NombreProyecto { get; set; }
        public int ProyectoId { get; set; }
    }

    public class ResumenVM
    {
        public int TotalProyectos { get; set; }
        public int TotalTareas { get; set; }
        public int TareasPendientes { get; set; }
        public int TareasAprobadas { get; set; }
        public TareaProxima[] Proximas { get; set; }
    }
}
