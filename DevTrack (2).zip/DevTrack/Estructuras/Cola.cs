namespace DevTrack.Estructuras
{
    /// <summary>
    /// Cola (Queue): el primero que entra es el primero que sale (FIFO).
    /// DevTrack la usa para las revisiones de QA: las tareas se revisan en orden de llegada.
    /// </summary>
    public class Cola<T>
    {
        private Nodo<T> _frente;   // el próximo en salir
        private Nodo<T> _final;    // el último que entró
        private int _cantidad;

        public int Cantidad => _cantidad;
        public bool EstaVacia => _frente == null;

        /// <summary>Agrega un elemento al final de la cola.</summary>
        public void Encolar(T elemento)
        {
            Nodo<T> nuevo = new Nodo<T>(elemento);

            if (_final == null)
            {
                // La cola estaba vacía: el nuevo es el frente y el final a la vez.
                _frente = nuevo;
                _final = nuevo;
            }
            else
            {
                _final.Siguiente = nuevo;
                _final = nuevo;
            }
            _cantidad++;
        }

        /// <summary>Saca y devuelve el elemento del frente.</summary>
        public T Desencolar()
        {
            if (_frente == null)
                throw new InvalidOperationException("La cola está vacía.");

            T dato = _frente.Dato;
            _frente = _frente.Siguiente;

            // Si ya no quedan nodos, el final también debe quedar en null.
            if (_frente == null)
                _final = null;

            _cantidad--;
            return dato;
        }

        /// <summary>Devuelve el elemento del frente sin sacarlo.</summary>
        public T VerFrente()
        {
            if (_frente == null)
                throw new InvalidOperationException("La cola está vacía.");

            return _frente.Dato;
        }

        /// <summary>Indica si algún elemento cumple la condición.</summary>
        public bool Contiene(Func<T, bool> condicion)
        {
            Nodo<T> actual = _frente;
            while (actual != null)
            {
                if (condicion(actual.Dato))
                    return true;
                actual = actual.Siguiente;
            }
            return false;
        }

        /// <summary>
        /// Quita de la cola todos los elementos que cumplan la condición, sin cambiar el orden de los demás.
        /// Se sacan todos a una cola auxiliar (solo los que se quedan) y luego se devuelven.
        /// </summary>
        public int EliminarDonde(Func<T, bool> condicion)
        {
            Cola<T> auxiliar = new Cola<T>();
            int eliminados = 0;

            while (!EstaVacia)
            {
                T elemento = Desencolar();
                if (condicion(elemento))
                    eliminados++;
                else
                    auxiliar.Encolar(elemento);
            }

            while (!auxiliar.EstaVacia)
                Encolar(auxiliar.Desencolar());

            return eliminados;
        }

        /// <summary>Copia la cola a un arreglo, del frente al final (útil para mostrar y guardar en JSON).</summary>
        public T[] ComoArreglo()
        {
            T[] copia = new T[_cantidad];
            Nodo<T> actual = _frente;
            int i = 0;
            while (actual != null)
            {
                copia[i] = actual.Dato;
                i++;
                actual = actual.Siguiente;
            }
            return copia;
        }

        public void Limpiar()
        {
            _frente = null;
            _final = null;
            _cantidad = 0;
        }
    }
}
