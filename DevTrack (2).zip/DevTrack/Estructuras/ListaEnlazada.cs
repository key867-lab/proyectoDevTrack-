namespace DevTrack.Estructuras
{
    /// <summary>
    /// Lista enlazada simple: cada nodo apunta al siguiente.
    /// DevTrack la usa para el historial de movimientos (el más reciente se agrega al inicio).
    /// </summary>
    public class ListaEnlazada<T>
    {
        private Nodo<T> _inicio;
        private Nodo<T> _fin;
        private int _cantidad;

        public int Cantidad => _cantidad;

        /// <summary>Agrega al inicio de la lista. O(1).</summary>
        public void AgregarAlInicio(T elemento)
        {
            Nodo<T> nuevo = new Nodo<T>(elemento);
            nuevo.Siguiente = _inicio;
            _inicio = nuevo;

            if (_fin == null)
                _fin = nuevo;

            _cantidad++;
        }

        /// <summary>Agrega al final de la lista. O(1) porque se guarda el último nodo.</summary>
        public void AgregarAlFinal(T elemento)
        {
            Nodo<T> nuevo = new Nodo<T>(elemento);

            if (_inicio == null)
            {
                _inicio = nuevo;
                _fin = nuevo;
            }
            else
            {
                _fin.Siguiente = nuevo;
                _fin = nuevo;
            }
            _cantidad++;
        }

        /// <summary>Recorre la lista de principio a fin y la copia a un arreglo.</summary>
        public T[] ComoArreglo()
        {
            T[] copia = new T[_cantidad];
            Nodo<T> actual = _inicio;
            int i = 0;
            while (actual != null)
            {
                copia[i] = actual.Dato;
                i++;
                actual = actual.Siguiente;
            }
            return copia;
        }

        public void Limpiar()
        {
            _inicio = null;
            _fin = null;
            _cantidad = 0;
        }
    }
}
